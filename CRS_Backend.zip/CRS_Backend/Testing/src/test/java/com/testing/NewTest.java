package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;


public class NewTest {
  @Test
  public void CrsTesting() throws InterruptedException{
	  System.out.println("Navigate to the Customer Login page");
	  wd.get("http://localhost:4200/customers");
	  wd.manage().window().maximize();
	  System.out.println("Done\n");
	  
	  System.out.println("Page load time");
	  long start = System.currentTimeMillis();
	  long finish = System.currentTimeMillis();
	  long totalTime = finish - start;
	  System.out.println("Total Time for page load - "+totalTime+"\n");
	  
	  System.out.println("Logging In");
	  WebElement EmailIDRef = wd.findElement(By.id("email"));
	  EmailIDRef.sendKeys("Saveri@gmail.com");
	  WebElement PasswordRef = wd.findElement(By.id("pass"));
	  PasswordRef.sendKeys("56776");
	  WebElement buttonRef = wd.findElement(By.id("submit"));
	  buttonRef.click();
	  System.out.println("Login done successfully\n");
	  
  }
  
  WebDriver wd;
  @BeforeMethod
  public void beforeMethod() {
  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\Saveri\\Java\\programs\\chromedriver_win32\\chromedriver.exe");
  wd=new ChromeDriver();
  }


  @AfterMethod
  public void afterMethod() {
  }

}
